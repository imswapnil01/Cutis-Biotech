import 'package:cutis_biotech/pages/visit/visit_form.dart';
import 'package:flutter/material.dart';

class VisitPage extends StatefulWidget {
  const VisitPage({super.key});

  @override
  State<VisitPage> createState() => _VisitPageState();
}

class _VisitPageState extends State<VisitPage> with SingleTickerProviderStateMixin {
  int selectedType = 0; // 0 = Doctors, 1 = Firms
  late TabController _tabController;

  // Dropdown values
  String selectedYear = '2024';
  String selectedMonth = 'April';
  String selectedVisitType = 'Today';
  String selectedEmployee = 'Select';

  // Dropdown options
  final years = ['2024', '2023', '2022'];
  final months = ['January', 'February', 'March', 'April'];
  final visitTypes = ['Today', 'All'];
  final employees = ['Select', 'Amit'];

  // Dummy data for visits
  final visits = [
    {'name': 'HARSHAL PATIL Sarvadnya ', 'location': 'Amravati', 'status': 'Open'},
    {'name': 'SANDEEP RATHOD NITYASEVA ', 'location': 'Wardha', 'status': 'Open'},
    {'name': 'SHANTANU BAVASKAR SHREE ', 'location': 'Nagpur', 'status': 'Open'},
  ];

  final primaryGreen = const Color(0xFF62a165);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Visits", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.green,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          // Toggle Buttons
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                _buildToggle("DOCTORS", 0),
                _buildToggle("FIRM'S", 1),
              ],
            ),
          ),

          // Show tabs only for Doctors
          if (selectedType == 0)
            TabBar(
              controller: _tabController,
              labelColor: primaryGreen,
              unselectedLabelColor: Colors.grey,
              indicatorColor: primaryGreen,
              tabs: const [Tab(text: 'TODAY'), Tab(text: 'ALL')],
            ),

          // Show dropdowns only for Firms
          if (selectedType == 1)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(child: _buildDropdown("Year", selectedYear, years, (val) => setState(() => selectedYear = val))),
                      const SizedBox(width: 10),
                      Expanded(child: _buildDropdown("Month", selectedMonth, months, (val) => setState(() => selectedMonth = val))),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(child: _buildDropdown("Type", selectedVisitType, visitTypes, (val) => setState(() => selectedVisitType = val))),
                      const SizedBox(width: 10),
                      Expanded(child: _buildDropdown("Employee", selectedEmployee, employees, (val) => setState(() => selectedEmployee = val))),
                    ],
                  ),
                ],
              ),
            ),

          // Visit List or Placeholder
          Expanded(
            child: selectedType == 0
                ? TabBarView(
              controller: _tabController,
              children: [
                _buildVisitList(),
                _buildVisitList(),
              ],
            )
                : const Center(child: Text("No visit data available for Firms.")),
          ),
        ],
      ),
    );
  }

  // Toggle Button Builder
  Widget _buildToggle(String title, int index) {
    bool selected = selectedType == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => selectedType = index),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected ? primaryGreen : Colors.grey.shade200,
            borderRadius: BorderRadius.circular(25),
          ),
          child: Center(
            child: Text(
              title,
              style: TextStyle(
                color: selected ? Colors.white : primaryGreen,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Dropdown Builder
  Widget _buildDropdown(String label, String value, List<String> options, Function(String) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(8),
          ),
          child: DropdownButton<String>(
            value: value,
            isExpanded: true,
            underline: const SizedBox(),
            onChanged: (val) => onChanged(val!),
            items: options.map((val) => DropdownMenuItem(value: val, child: Text(val))).toList(),
          ),
        ),
      ],
    );
  }

  // Visit List Builder
  Widget _buildVisitList() {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: visits.length,
      itemBuilder: (context, index) {
        final visit = visits[index];
        final initial = visit['name']![0];

        return Card(
          elevation: 3,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.blue.shade100,
              child: Text(initial, style: TextStyle(color: primaryGreen, fontWeight: FontWeight.bold)),
            ),
            title: Text(visit['name']!, overflow: TextOverflow.ellipsis),
            subtitle: Row(
              children: [
                const Icon(Icons.location_on, size: 14, color: Colors.grey),
                Text(" ${visit['location']}  "),
                Icon(Icons.check_circle, size: 14, color: primaryGreen),
                Text(" ${visit['status']!}", style: TextStyle(color: primaryGreen)),
              ],
            ),
            onTap: () {
              showVisitPopup(context, visit['name']!);
            },


          ),
        );
      },
    );
  }
}
void showVisitPopup(BuildContext context, String doctorName) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade400),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => VisitFormPage()));

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Going to visit $doctorName")),
                  );
                },
                child: Text("Go to Visit" , style: TextStyle(color: Colors.white)),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                onPressed: () {
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Skipped visit for $doctorName")),
                  );
                },
                child: Text("Skip Visit",style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        ),
      );
    },
  );
}